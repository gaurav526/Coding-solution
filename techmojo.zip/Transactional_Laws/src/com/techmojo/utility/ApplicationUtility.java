package com.techmojo.utility;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class ApplicationUtility {

	// Method to validate time
	private static boolean isTimeValid(String tm) {
		Pattern pattern = Pattern.compile("(1[012]|[1-9]):[0-5][0-9](\\s)?(?i)(am|pm)");
		return pattern.matcher(tm).matches();
	}

	// Method to validate time
	private static boolean isDateValid(String dt) {
		 if (dt == null || !dt.matches("\\d{4}-[01]\\d-[0-3]\\d"))
		        return false;
		    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		    df.setLenient(false);
		    try {
		        df.parse(dt);
		        return true;
		    } catch (ParseException ex) {
		        return false;
		    }
	}

	// Method to format Date and Time in Date Object
	private static Date formatDateTime(String dt, String time) {
		if (isDateValid(dt) && isTimeValid(time)) {
			String format = "yyyy-MM-dd hh:mm a";
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			Date dateTimeMillis = null;
			try {
				dateTimeMillis = sdf.parse(dt + " " + time);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return dateTimeMillis;
		} else
			return null;
	}

	// Method to format Date in year,months,days,hours,minutes,seconds
	private static String formatTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int am_pm = cal.get(Calendar.AM_PM);
		String ampm = "ampm";
		if (am_pm == 0) {
			ampm = "AM";
		} else {
			ampm = "PM";
		}
		String formatedDateTime = cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-"
				+ cal.get(Calendar.DATE) + "  |  " + cal.get(Calendar.HOUR) + ":" + cal.get(Calendar.MINUTE) + ":"
				+ cal.get(Calendar.SECOND) + "  " + ampm;

		return formatedDateTime;
	}

	// Method to validate status
	private static boolean isStatusValid(String st) {
		if (st != null && (st.equalsIgnoreCase("start") || st.equalsIgnoreCase("end")))
			return true;
		else
			return false;
	}

	// Method to validate Id
	private static boolean isIdValid(String st) {
		if (st != null && st.length() > 0)
			return true;
		else
			return false;
	}

	// Method to calculate average
	public static Map<String, String> getAverageTime(ArrayList<String> arrayList) throws ParseException {
		int error = 0;
		List<String> transactionId = new ArrayList<>();
		List<Date> transactionDate = new ArrayList<>();
		List<String> transactionStatus = new ArrayList<>();
		Map<String, String> result = new HashMap<>();
		Date formatteddate = null;
		for (int index = 0; index < arrayList.size(); index++) {
			String[] splittedData = arrayList.get(index).split(",");
			formatteddate = formatDateTime(splittedData[1].replaceAll(" ", "").replaceAll("–", "-"),
					splittedData[2].trim());
			if (formatteddate != null && isStatusValid(splittedData[3].trim()) && isIdValid(splittedData[0].trim())) {
				transactionId.add(splittedData[0].trim());
				transactionDate.add(formatteddate);
				transactionStatus.add(splittedData[3].trim());
			} else {
				error++;
			}
		}

		if (!transactionId.isEmpty() && !transactionStatus.isEmpty() && !transactionDate.isEmpty()) {
			for (int i = 0; i < transactionId.size(); i++) {
				for (int j = i + 1; j < transactionId.size(); j++) {
					if (transactionId.get(i).equalsIgnoreCase(transactionId.get(j))
							&& ((transactionStatus.get(i).equalsIgnoreCase("start") && transactionStatus.get(j).equalsIgnoreCase("end"))
							|| (transactionStatus.get(i).equalsIgnoreCase("end") && transactionStatus.get(j).equalsIgnoreCase("start")))) {
						ArrayList<Date> dates = new ArrayList<>();
						boolean isPreDate=false;
						if(transactionStatus.get(i).equalsIgnoreCase("start") && transactionStatus.get(j).equalsIgnoreCase("end")){
							isPreDate=checkPreviousDate(transactionDate.get(i),transactionDate.get(j));
						}else{
						isPreDate=checkPreviousDate(transactionDate.get(j),transactionDate.get(i));
						}
						if(isPreDate){
						dates.add(transactionDate.get(j));
						dates.add(transactionDate.get(i));
						BigInteger total = BigInteger.ZERO;
						for (Date date : dates) {
							if (date != null) {
								total = total.add(BigInteger.valueOf(date.getTime()));
							}
						}
						BigInteger averageMillis = total.divide(BigInteger.valueOf(dates.size()));
						Date averageDate = new Date(averageMillis.longValue());
						result.put(transactionId.get(i), formatTime(averageDate));
						}
					}
				}
			}
		}
		result.put("error", Integer.toString(error));
		return result;
	}
	private static boolean checkPreviousDate(Date startDate, Date endDate) {
		  if(endDate.before(startDate)){
			  return false;
	        } else {
	        	return true;
	        }
		
	}

}
